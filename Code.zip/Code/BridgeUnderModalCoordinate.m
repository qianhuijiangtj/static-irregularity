classdef BridgeUnderModalCoordinate < handle
    %BRIDGEUNDERMODALCOORD Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        nodePosition
        railNodeId
        freqInfo % [order,circular freq,freq,period]
        modeShapeInfo % [nodeid,order,dof1,dof2,...,dof6]
        Xi
        verticalDirection
        postObj % [nodeid dof]
        modeCntToCal
        
        modeCnt
        nodeCnt
        railNodeCnt
        dofCntPerNode
        dofCnt
        postObjCnt
        phi
        phiPost

        Mbar
        Cbar
        Kbar

        railXMin
        railXMax
        railLength
    end
    
    methods
        function obj = BridgeUnderModalCoordinate(nodePosition,railNodeId,freqInfo,modeShapeInfo,Xi,verticalDirection,postObj,modeCntToCal)
            obj.nodePosition=nodePosition;
            obj.railNodeId=railNodeId;
            obj.freqInfo=freqInfo;
            obj.modeShapeInfo=modeShapeInfo;
            obj.Xi=Xi;
            obj.verticalDirection=verticalDirection;
            obj.postObj=postObj;
            obj.modeCnt=size(freqInfo,1);
            obj.nodeCnt=size(nodePosition,1);
            obj.railNodeCnt=length(railNodeId);
            obj.dofCntPerNode=size(modeShapeInfo,2)-2;
            obj.dofCnt=obj.nodeCnt*obj.dofCntPerNode;
            obj.postObjCnt=size(obj.postObj,1);
            if modeCntToCal > obj.modeCnt
                warning("modeCntToCal exceeds total mode count. It's been reset to total mode count.");
                obj.modeCntToCal=obj.modeCnt;
            else
                obj.modeCntToCal=modeCntToCal;
            end
            obj.assemblePhi();
            obj.assemblePhibPost();
            obj.assembleDynamicalMatrix();
            obj.calculateRailInfo();
        end

        function obj = assemblePhi(obj)
            mat2reshape = transpose(obj.modeShapeInfo(:, 3:3+obj.dofCntPerNode-1));
            sz = [obj.dofCntPerNode, obj.nodeCnt, obj.modeCnt];
            obj.phi = reshape(mat2reshape, sz);
            obj.phi = permute(obj.phi, [3, 2, 1]);
            obj.phi = obj.phi(1:obj.modeCntToCal,:,:);
        end
        
        function obj = assemblePhibPost(obj)
            obj.phiPost=zeros(obj.modeCntToCal,obj.postObjCnt);
            for iObj = 1:obj.postObjCnt
                obj.phiPost(:,iObj)=obj.phi(1:obj.modeCntToCal,obj.postObj(iObj,1),obj.postObj(iObj,2));
            end
        end

        function obj = assembleDynamicalMatrix(obj)
            obj.Mbar = eye(obj.modeCntToCal);
            obj.Cbar = 2 * obj.Xi * eye(obj.modeCntToCal) * diag(obj.freqInfo(1:obj.modeCntToCal, 2));
            obj.Kbar = diag(obj.freqInfo(1:obj.modeCntToCal, 2)) .^ 2;
        end

        function obj = calculateRailInfo(obj)
            railNodeX = zeros(obj.railNodeCnt,1);
            for iRailNode = 1:obj.railNodeCnt
                [iRow,~] = find(obj.nodePosition(:,1)==obj.railNodeId(iRailNode));
                railNodeX(iRailNode) = obj.nodePosition(iRow,2);
            end
            obj.railXMin = min(railNodeX);
            obj.railXMax = max(railNodeX);
            obj.railLength = obj.railXMax - obj.railXMin;
        end
    end
end

