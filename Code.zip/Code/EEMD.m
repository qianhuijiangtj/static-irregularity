function [imf, res] = EEMD(x, N, Std)
% EEMD: 集合经验模态分解（基于MATLAB自带emd函数）
% 输入参数：
%   x    - 原始信号（一维向量）
%   N    - 分解次数（建议100-1000，次数越多越稳定，默认200）
%   Std  - 噪声标准差比例 (默认0.2，相对于信号标准差)
% 输出参数：
%   imf  - 分解后的IMF分量（矩阵，每一列是一个IMF）
%   res  - 最终残余分量（一维向量）

    % 1. 参数初始化
    if nargin < 2, N = 200; end          % 默认分解200次
    if nargin < 3, Std = 0.2; end         % 默认信噪比20dB
    imf_sum = [];                        % 存储所有分解的IMF总和（用于后续平均）
    res_sum = 0;                         % 存储所有分解的残余总和
    
    % 2. 计算噪声强度
    sigma_x = std(x);
    sigma_noise = sigma_x * Std;
    
    % 3. 多次添加噪声+EMD分解
    fprintf('EEMD分解中... 共需执行%d次EMD\n', N);
    for i = 1:N
        % 生成与信号等长的高斯白噪声（均值0，标准差sigma_noise）
        noise = sigma_noise * randn(size(x,1), size(x,2));
        
        % 给原始信号添加噪声
        x_noisy = x + noise;
        
        % 调用MATLAB自带emd函数分解（返回IMF和残余）
        % 'Display', 'off' 关闭每次EMD的迭代显示（减少冗余输出）
        [imf_i, res_i] = emd(x_noisy,"MaxNumIMF",30,"SiftRelativeTolerance",0.05,"SiftMaxIterations",200);
        
        % 累加当前分解的IMF和残余（用于后续平均）
        % 第一次分解时，初始化imf_sum的维度
        if isempty(imf_sum)
            imf_sum = imf_i;
            num_imf = size(imf_sum, 2); % 记录IMF数量
        else
            % 若当前imf_i的列数少于num_imf，补零列
            if size(imf_i, 2) < num_imf
                imf_i = [imf_i, zeros(size(imf_i, 1), num_imf - size(imf_i, 2))];
            % 若当前imf_i的列数多于num_imf，截断列
            else
                imf_i = imf_i(:, 1:num_imf);
            end
            imf_sum = imf_sum + imf_i;
        end
        res_sum = res_sum + res_i;
        
        % 打印进度（每10次输出一次）
        if mod(i, 10) == 0
            fprintf('已完成%d/%d次分解\n', i, N);
        end
    end
    
    % 4. 对所有分解结果取平均（核心步骤：抵消噪声影响）
    imf = imf_sum / N;  % 同阶IMF取平均，得到最终IMF
    res = res_sum / N;  % 残余分量取平均，得到最终残余
    
    % 5. 验证：IMF+残余是否近似原始信号（可选输出）
    recon_x = sum(imf, 2) + res;
    recon_error = norm(x - recon_x) / norm(x);  % 相对重构误差
    fprintf('EEMD分解完成！重构相对误差：%.4e\n', recon_error);
end