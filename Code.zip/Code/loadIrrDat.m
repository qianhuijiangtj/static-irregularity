function [vertIrr, dirtIrr, horzIrr, sampleItv] = loadIrrDat(vbcDir, fileName, briLen)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明

irrFilePath = strcat(vbcDir, '\', fileName);
lines = readlines(irrFilePath, "WhitespaceRule", "trim");

pat = whitespacePattern | ',';
metaData1 = str2double(split(lines(2), pat));
metaData2 = str2double(split(lines(4), pat));
metaData3 = str2double(split(lines(6), pat));

smoothLen = metaData2(1);
sampleItv = metaData1(7);
vertCoe = metaData3(1);
dirtCoe = metaData3(2);
horzCoe = metaData3(3);

if sampleItv * size(lines, 1) + 7 > briLen
    lines(floor(briLen/sampleItv):end, :) = [];
end

irrData = str2double(split(lines(8:end-1), pat));

for i = 1:(smoothLen/sampleItv)
    irrData(i, :) = irrData(i, :) * (i / (smoothLen/sampleItv));
    irrData(end-i+1, :) = irrData(end-i+1, :) * (i / (smoothLen/sampleItv));
end

vertIrr = irrData(:, 1) .* vertCoe;
dirtIrr = irrData(:, 2) .* dirtCoe;
horzIrr = irrData(:, 3) .* horzCoe;

end
