clear;
clc;
runInBackground = 'n';
forwardProblemMatFilePath1 = "simu_forward_ssd_60kph.mat"; % 正问题代码生成的mat文件
forwardProblemMatFilePath2 = "simu_forward_ssd_60kph.mat";
measurementSnr = 15;
noiseSeed = 2;
 % measuredIdx = [17,35:38,43,46];
%measuredIdx = [1:20];
% measuredIdx = [17,35,43];
% measuredIdx = [35,47];
measuredIdx = [35:36,43];
inverseSimuRstDirToSave = ".";

load(forwardProblemMatFilePath2);
sensorPureSignal = squeeze(forwardSimuOut.yk.signals.values(measuredIdx,:,:))'; % 观测量多于1个时，需要将矩阵转置否则提示输入不兼容
signalTimeStamp = forwardSimuOut.yk.time;
load(forwardProblemMatFilePath1);
invOpr = InverseOperationByAkfVehicleBridgeCoupling(sensorPureSignal,signalTimeStamp,fwdOpr,measuredIdx,measurementSnr,noiseSeed);
measuredIdxStr = intListToStr(measuredIdx);

% Run simulink
if runInBackground ~= 'y'
    open_system("InverseProblem.slx");
end
options=simset('SrcWorkspace','current');
inverseSimuOut = sim('InverseProblem',[],options);
inverseRstFileName = sprintf("%s\\simu_inverse_%dkph_measure%s_snr%d.mat", inverseSimuRstDirToSave, round(invOpr.forwardOpr.velocity*3.6), measuredIdxStr, measurementSnr);
save(inverseRstFileName, "inverseSimuOut", "invOpr", "-mat", "-v7.3");