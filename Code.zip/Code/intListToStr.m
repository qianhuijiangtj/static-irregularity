function intStrList = intListToStr(intList)
%INTLISTTOSTR Summary of this function goes here
%   Detailed explanation goes here
intList = sort(intList);
rangeEndPts = find(diff(intList)>1);
rangeEnds = intList([rangeEndPts, end]);
rangeStarts = [intList(1), intList(rangeEndPts+1)];
rangeStrList = strings(size(rangeEnds));
for iRange = 1:length(rangeEnds)
    if rangeStarts(iRange) == rangeEnds(iRange)
        rangeStrList(iRange) = num2str(rangeStarts(iRange));
    else
        rangeStrList(iRange) = num2str(rangeStarts(iRange)) + "-" + num2str(rangeEnds(iRange));
    end
end
intStrList = "[" + join(rangeStrList, ',') + "]";
end

