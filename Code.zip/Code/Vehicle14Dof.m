classdef Vehicle14Dof < handle
    %Vehicle14Dof Summary of this class goes here
    %   Detailed explanation goes here

    properties (GetAccess = public, SetAccess = protected)
        Mc %mass of car body
        Jc %inertia of car body
        Mt %mass of bogie
        Jt %inertia of bogie
        Mw %mass of wheelset

        Cpz %damping of primary suspension
        Csz %damping of secondary suspension

        Kpz %stiffness of primary suspension
        Ksz %stiffness of secdondary suspension
        Kh %stiffness of wheel-rail contact

        Lc %HALF of the distance between two boogies
        Lt %HALF of the distance between two wheelsets
        Le %HALF of the distance between two ends of car body
        wheelPositions

        gravity
        Fg

        M
        C
        K
        KhMat

        zInitCondUnderGrav
    end

    properties (GetAccess = public, Constant = true)
        dofCnt = 14
        irrInputIdx = [11, 12, 13, 14]
        gravIdx = [1,3,5,7,8,9,10];
    end

    methods
        function obj = Vehicle14Dof(Mc,Jc,Mt,Jt,Mw,Cpz,Csz,Kpz,Ksz,Kh,Lc,Lt,Le,gravity)
            obj.Mc=Mc;
            obj.Jc=Jc;
            obj.Mt=Mt;
            obj.Jt=Jt;
            obj.Mw=Mw;
            obj.Cpz=Cpz;
            obj.Csz=Csz;
            obj.Kpz=Kpz;
            obj.Ksz=Ksz;
            obj.Kh=Kh;
            obj.Lc=Lc;
            obj.Lt=Lt;
            obj.Le=Le;
            obj.wheelPositions=[0,-2*obj.Lt,-2*obj.Lc,-2*(obj.Lt+obj.Lc)];
            obj.gravity=gravity;

            obj.assembleDynamicalMatrix();
            obj.calGravityForce();
            obj.solveZInitCond();
        end

        function obj = assembleDynamicalMatrix(obj)
            obj.M = diag([obj.Mc, obj.Jc, obj.Mt, obj.Jt, obj.Mt, obj.Jt, ...
                obj.Mw, obj.Mw, obj.Mw, obj.Mw, 0, 0, 0, 0], 0);

            C_up = [2*obj.Csz, 0, -obj.Csz, 0, -obj.Csz, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 2*obj.Csz*obj.Lc^2, obj.Csz*obj.Lc, 0, -obj.Csz*obj.Lc, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 0, 2*obj.Cpz+obj.Csz, 0, 0, 0, -obj.Cpz, -obj.Cpz, 0, 0, 0, 0, 0, 0; 
                    0, 0, 0, 2*obj.Cpz*obj.Lt^2, 0, 0, obj.Cpz*obj.Lt, -obj.Cpz*obj.Lt, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 2*obj.Cpz+obj.Csz, 0, 0, 0, -obj.Cpz, -obj.Cpz, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 2*obj.Cpz*obj.Lt^2, 0, 0, obj.Cpz*obj.Lt, -obj.Cpz*obj.Lt, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, obj.Cpz, 0, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, obj.Cpz, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, obj.Cpz, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, obj.Cpz, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            obj.C = C_up + C_up' - diag(diag(C_up));
            
            K_up = [2*obj.Ksz, 0, -obj.Ksz, 0, -obj.Ksz, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 2*obj.Ksz*obj.Lc^2, obj.Ksz*obj.Lc, 0, -obj.Ksz*obj.Lc, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                    0, 0, obj.Ksz+2*obj.Kpz, 0, 0, 0, -obj.Kpz, -obj.Kpz, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 2*obj.Kpz*obj.Lt^2, 0, 0, obj.Kpz*obj.Lt, -obj.Kpz*obj.Lt, 0, 0, 0, 0, 0, 0;
                    0, 0, 0, 0, obj.Ksz+2*obj.Kpz, 0, 0, 0, -obj.Kpz, -obj.Kpz, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 2*obj.Kpz*obj.Lt^2, 0, 0, obj.Kpz*obj.Lt, -obj.Kpz*obj.Lt, 0, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, obj.Kpz+obj.Kh, 0, 0, 0, -obj.Kh, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, obj.Kpz+obj.Kh, 0, 0, 0, -obj.Kh, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, obj.Kpz+obj.Kh, 0, 0, 0, -obj.Kh, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, obj.Kpz+obj.Kh, 0, 0, 0, -obj.Kh;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, obj.Kh, 0, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, obj.Kh, 0, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, obj.Kh, 0;
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, obj.Kh];
            obj.K = K_up + K_up' - diag(diag(K_up));

            noIrrDofCnt = obj.dofCnt - length(obj.irrInputIdx);
            obj.KhMat = [zeros(noIrrDofCnt, length(obj.irrInputIdx)); 
            obj.Kh * eye(length(obj.irrInputIdx))];
        end

        function obj = calGravityForce(obj)
            gravVec = obj.gravity * ones(obj.dofCnt, 1);
            noGravIdx = setdiff(1:obj.dofCnt, obj.gravIdx);
            gravVec(noGravIdx) = 0;
            obj.Fg = obj.M*gravVec;
        end

        function obj = solveZInitCond(obj)
            obj.zInitCondUnderGrav = [(obj.K(obj.noIrrDofIdx, obj.noIrrDofIdx))^-1 * obj.Fg(obj.noIrrDofIdx);
                                    zeros(obj.irrDofCnt,1)];
        end

        function noIrrDofIdx = noIrrDofIdx(obj)
            noIrrDofIdx = setdiff(1:obj.dofCnt, obj.irrInputIdx);
        end

        function noIrrDofCnt = noIrrDofCnt(obj)
            noIrrDofCnt = obj.dofCnt - length(obj.irrInputIdx);
        end

        function irrDofCnt = irrDofCnt(obj)
            irrDofCnt = length(obj.irrInputIdx);
        end

    end
end