% ============Mass and Inertia===============
Mc=47010*1.0; %mass of car body
Jc=1983000; %inertia of car body
Mt=4600; %mass of bogie
Jt=3200; %inertia of bogie
Mw=1590; %mass of wheelset
Kh = 1e8;

% ============Damp Coefficient===============
Cpz=2 * 20e3 ; %damping of primary suspension
Csz=2 * 22e3 ; %damping of secondary suspension

% ============Stiffness===============
Kpz=2 * 1.229e6; %stiffness of primary suspension
Ksz=2 * 0.446e6 ; %stiffness of secdondary suspension
% 二系悬挂还有个减震器串联刚度暂未考虑，垂向9MN/m

% ============Geometry===============
Lc=15.7/2; %HALF of the distance between two boogies
Lt=2.5/2; %HALF of the distance between two wheelsets
Le = 25.3/2; %HALF of the distance between two ends of car body