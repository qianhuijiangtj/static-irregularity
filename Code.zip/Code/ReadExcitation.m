function [excitationSample, dtIrr, dxIrr, velocity] = ReadExcitation(vbcDir, I_Speed, num_Unit, type, briLen)
%Get the excitation for 4 wheelsets from VBC result files
% vbcDir: the dir of vbc calculation files (inside it are *.bin, *.dat)
% I_Speed: speed switch of vbc
% num_Unit: index of the concerned car
% type: 
% irrSample: [length×4], Forced displacement time hist of the 4 wheelsets
% dt: time step of vbc result, also the time step of irrSample

file_wheeldis = 'Res_WheelsetirregDisVehilces.bin';%轮轨横向相对位移, etc.
file_static = 'Irregularity.dat';

Index1 = 1:6:24; %每个Unit的第Index个参数: 1-轮下轨道位移（含静态不平顺+结构位移）
DataNumPerUnit=24;
I_Concerned1=[DataNumPerUnit*(num_Unit-1)+Index1]; %#ok<NBRAK>
Index2 = 4:6:24; %每个Unit的第Index个参数: 4-轮轨竖向相对位移
I_Concerned2=[DataNumPerUnit*(num_Unit-1)+Index2]; %#ok<NBRAK>

[~,Speeds]=GetVehicleOrg(vbcDir);
velocity = Speeds(I_Speed); %这种写法仅支持一列上道车的工况（此时Speeds为向量）
velocity = velocity/3.6;

switch type
    case 'wheel-disvbcDir,file_wheeldisplacement'
        [dtIrr,Y1,~] = VBCdataRead(vbcDir,file_wheeldis,I_Speed,I_Concerned1);
        [~,Y2,~] = VBCdataRead(vbcDir,file_wheeldis,I_Speed,I_Concerned2);
        excitationSample = (Y1+Y2)*1e-3; %输出单位为m
        dxIrr = dtIrr * velocity;
    case 'dynamic-irr'
        [dtIrr,Y1,~] = VBCdataRead(vbcDir,file_wheeldis,I_Speed,I_Concerned1);
        excitationSample = Y1*1e-3;
        dxIrr = dtIrr * velocity;
    case 'static'
        %read and process Irregularity.dat (dx -> dt)
        [vertIrr, ~, ~, dxIrr] = loadIrrDat(vbcDir, file_static, briLen);
        dtIrr = dxIrr / velocity;
        excitationSample = vertIrr;
end

end
