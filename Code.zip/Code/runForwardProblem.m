clear;clc
gravityOnVeh = 9.81; % unit in m/s2
vbcDir = "D:\JQH";
bridgeModeFilePath = sprintf("%s\\Bridge_modalvectors_TrainingLine.dat", vbcDir);
msbFilePath = sprintf("%s\\Modal_Substructure_Bridge.dat", vbcDir);
TsOfDiscreteModel = 1e-4;
velocity = 60 / 3.6;
preDistance = 0;
postDistance = 150;
runInBackground = 'n';
forwardSimuRstDirToSave = ".";

%% build vehicle model
setParaForMetroAVertical;
veh14dof = Vehicle14Dof(Mc,Jc,Mt,Jt,Mw,Cpz,Csz,Kpz,Ksz,Kh,Lc,Lt,Le,gravityOnVeh);

%% import bridge model (modal coordinates)
[freqInfo, modeShapeInfo] = loadModalDat(bridgeModeFilePath, 'Z');
[nodePosition, railNodeId] = loadMsbDat(msbFilePath, 'Z');
[r,~] = find(modeShapeInfo(:,1)==20000);
modeShapeInfo(r,:) = [];
Xi = 0.05;
verticalDirection = 3;
postObj = [87,3;
            261,3;
            435,3];
modeCntToCal = 60;
bridge = BridgeUnderModalCoordinate(nodePosition,railNodeId,freqInfo,modeShapeInfo,Xi,verticalDirection,postObj,modeCntToCal);

%% setup forward operation
[irrSample, ~, ~, dxIrr] = loadIrrDat(vbcDir, 'Irregularity.dat', bridge.railLength);
xStamp = (0:size(irrSample,1)-1)' * dxIrr + bridge.railXMin;
irrSample = [xStamp, -irrSample];
vehicleHeadInitX = bridge.railXMin - preDistance;
vehicleTailEndX = bridge.railXMax + postDistance;
fwdOpr = ForwardOperationVehicleBridgeCoupling(veh14dof,bridge,irrSample,velocity,vehicleHeadInitX,vehicleTailEndX,TsOfDiscreteModel);

%% run forward operation
if runInBackground ~= 'y'
    open_system("ForwardProblem.slx");
end
options=simset('SrcWorkspace','current');
forwardSimuOut = sim('ForwardProblem',[],options);
forwardRstFileName = sprintf("%s\\simu_forward_ssd_%dkph.mat", forwardSimuRstDirToSave, round(velocity*3.6));
save(forwardRstFileName, "forwardSimuOut", "fwdOpr", "-mat", "-v7.3");