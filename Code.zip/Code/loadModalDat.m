function [freqInfoMat, shapeInfoMat] = loadModalDat(modeFilePath, upAxisOfOutPut)
% read modal information from modeVectors.dat
%   upAxisOfOutput: wanted up axis of the returned matrices, 'Y' / 'Z'
%   freqInfoMat: [mode order, cycle freq, freq, period]
%   shapeInfoMat: [node id, mode order, x, y, z, rx, ry, rz]

lines = readlines(modeFilePath, "WhitespaceRule","trim");

% split the dat into sections roughly
freqInfoStartLine = 0;
freqInfoEndLine = 0;
shapeInfoStartLine = 0;
shapeInfoEndLine = 0;
for iLine = 1:size(lines, 1)
    if contains(lines(iLine), "(rad/sec)")
        freqInfoStartLine = iLine + 1;
    end
    if contains(lines(iLine), "(N,m)")
        shapeInfoStartLine = iLine + 1;
        freqInfoEndLine = iLine - 1;
    end
    if contains(lines(iLine), "Stress")
        stressInfoStartLine = iLine + 1;
        shapeInfoEndLine = iLine - 1;
    end
end

% find exact end lines of each section
for iLine = freqInfoEndLine:-1:freqInfoStartLine
    if startsWith(lines(iLine), digitsPattern)
        freqInfoEndLine = iLine;
        break;
    end
end
for iLine = shapeInfoEndLine:-1:shapeInfoStartLine
    if startsWith(lines(iLine), digitsPattern)
        shapeInfoEndLine = iLine;
        break;
    end
end

freqInfoMat = str2double(split(lines(freqInfoStartLine:freqInfoEndLine)));
shapeInfoMat = str2double(split(lines(shapeInfoStartLine:shapeInfoEndLine)));

projectDirArr = split(modeFilePath, '\');
projectDir = join(projectDirArr(1:end-1), '\');
upAxis = loadSolPara(projectDir);
if upAxis ~= upAxisOfOutPut
    shapeInfoMat(:, [4, 5]) = shapeInfoMat(:, [5, 4]);
    shapeInfoMat(:, [7, 8]) = shapeInfoMat(:, [8, 7]);
end