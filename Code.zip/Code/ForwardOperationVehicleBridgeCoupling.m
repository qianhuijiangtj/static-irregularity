classdef ForwardOperationVehicleBridgeCoupling < handle
    %FORWARDOPERATION Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        veh14dof
        bridge
        
        irrSample
        velocity
        vehicleHeadInitX
        vehicleTailEndX
        vehicleWheelsInitX
        vehicleWheelsEndX

        Ts
        simDuration
        simTimeSignal

        stateSpaceInitCond
        stateCnt
    end
    
    methods
        function obj = ForwardOperationVehicleBridgeCoupling(veh14dof,bridge,irrSample,velocity,vehicleHeadInitX,vehicleTailInitX,Ts)
            obj.veh14dof=veh14dof;
            obj.bridge=bridge;
            obj.irrSample=irrSample;
            obj.velocity=velocity;
            obj.vehicleHeadInitX=vehicleHeadInitX;
            obj.vehicleTailEndX=vehicleTailInitX;
            obj.vehicleWheelsInitX=obj.vehicleHeadInitX-(obj.veh14dof.Le-obj.veh14dof.Lc)+obj.veh14dof.Lt+obj.veh14dof.wheelPositions;
            obj.vehicleWheelsEndX=obj.vehicleTailEndX+(obj.veh14dof.Le+obj.veh14dof.Lc)+obj.veh14dof.Lt+obj.veh14dof.wheelPositions;
            obj.Ts=Ts;
            obj.simDuration=abs(obj.vehicleWheelsEndX(1)-obj.vehicleWheelsInitX(1))/velocity;
            obj.simTimeSignal=[0,0;obj.simDuration,obj.simDuration];
            obj.calStateSpaceInitCond();
            obj.stateCnt=length(obj.stateSpaceInitCond);
        end

        function obj = calStateSpaceInitCond(obj)
            Mvv = obj.veh14dof.M(obj.veh14dof.noIrrDofIdx, obj.veh14dof.noIrrDofIdx);
            Kvv = obj.veh14dof.K(obj.veh14dof.noIrrDofIdx, obj.veh14dof.noIrrDofIdx);
            Cvv = obj.veh14dof.C(obj.veh14dof.noIrrDofIdx, obj.veh14dof.noIrrDofIdx);
            Mvwp = obj.veh14dof.M(obj.veh14dof.noIrrDofIdx, obj.veh14dof.irrInputIdx);
            Kvwp = obj.veh14dof.K(obj.veh14dof.noIrrDofIdx, obj.veh14dof.irrInputIdx);
            Cvwp = obj.veh14dof.C(obj.veh14dof.noIrrDofIdx, obj.veh14dof.irrInputIdx);
            Mvww = obj.veh14dof.M(obj.veh14dof.irrInputIdx, obj.veh14dof.irrInputIdx);
            Kvww = obj.veh14dof.K(obj.veh14dof.irrInputIdx, obj.veh14dof.irrInputIdx);
            Cvww = obj.veh14dof.C(obj.veh14dof.irrInputIdx, obj.veh14dof.irrInputIdx);
            
            targetX = obj.vehicleWheelsInitX;
            PhibX = zeros(obj.bridge.modeCntToCal, obj.veh14dof.irrDofCnt);
            for iMode = 1:obj.bridge.modeCntToCal
                PhibX(iMode, :) = interp1(obj.bridge.nodePosition(:, 2), obj.bridge.phi(iMode, :, obj.bridge.verticalDirection), targetX, 'spline', 0);
            end
            PhibX = PhibX';
            
            irrDx = obj.irrSample(2, 1) - obj.irrSample(1, 1);
            irrDt = irrDx / obj.velocity;
            R = obj.irrSample(:, 2);
            RDot = diff(R)/irrDt;
            RDotDot = diff(diff(R))/irrDt^2;
            RX = interp1(obj.irrSample(:, 1), R, targetX', 'spline', 0); % irr at point targetX
            RDotX = interp1(obj.irrSample(1:end-1, 1), RDot, targetX', 'spline', 0);
            RDotDotX = interp1(obj.irrSample(1:end-2, 1), RDotDot, targetX', 'spline', 0);
            
            MbStar = PhibX' * Mvww * PhibX;
            CbStar = PhibX' * Cvww * PhibX;
            KbStar = PhibX' * Kvww * PhibX;
            MvbStar = Mvwp * PhibX;
            CvbStar = Cvwp * PhibX;
            KvbStar = Kvwp * PhibX;
            
            Mc = [Mvv, MvbStar; MvbStar', obj.bridge.Mbar + MbStar];
            Cc = [Cvv, CvbStar; CvbStar', obj.bridge.Cbar + CbStar];
            Kc = [Kvv, KvbStar; KvbStar', obj.bridge.Kbar + KbStar];
            
            PvStar = obj.veh14dof.Fg(obj.veh14dof.noIrrDofIdx) - Cvwp * RDotX - Kvwp * RX;
            PbStar = PhibX' * (obj.veh14dof.Fg(obj.veh14dof.irrInputIdx) - Mvww * RDotDotX - Cvww * RDotX - Kvww * RX);
            Fc = [PvStar; PbStar];

            obj.stateSpaceInitCond = [Kc^-1*Fc; zeros(size(Kc,1),1)];
        end
        

    end
end

