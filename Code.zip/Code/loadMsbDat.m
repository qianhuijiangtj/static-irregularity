function [bridgeNodePosition, railNodeId] = loadMsbDat(msbFilePath, upAxisOfOutput)
% read bridge nodes' position and rail nodes' id from msb.dat
%   msbFilePath: abstract path of msb.dat;
%   upAxisOfOutput: wanted up axis of the returned matrices, 'Y' / 'Z'

lines = readlines(msbFilePath, 'EmptyLineRule', 'skip', 'WhitespaceRule', 'trim');
pat = whitespacePattern | ',';
metaData = str2double(split(lines(1), pat));
bridgeNodeCnt = metaData(1);
railNodeCnt = metaData(2);

bridgeNodePosition = str2double(split(lines(2:bridgeNodeCnt+1)));
railNodeId = str2double(split(lines(bridgeNodeCnt+2:bridgeNodeCnt+1+railNodeCnt)));

projectDirArr = split(msbFilePath, '\');
projectDir = join(projectDirArr(1:end-1), '\');
upAxis = loadSolPara(projectDir);
if upAxis ~= upAxisOfOutput
    bridgeNodePosition(:, [3, 4]) = bridgeNodePosition(:, [4, 3]);
end

end
