function [upAxis] = loadSolPara(projectDir)
% read solve parameters of VBC project
%   upAxis: the up axis of the VBC project

if projectDir(end) ~= '\'
    projectDir = append(projectDir, '\');
end
filePath = append(projectDir, 'SolutionParameters.dat');
lines = readlines(filePath, 'EmptyLineRule', 'skip', 'WhitespaceRule', 'trim');
line5Vec = split(lines(5));
axisCode = str2double(line5Vec(1));

if axisCode == 0
    upAxis = 'Y';
else
    upAxis = 'Z';
end

end
