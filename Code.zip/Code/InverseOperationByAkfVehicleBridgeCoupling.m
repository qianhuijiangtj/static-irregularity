classdef InverseOperationByAkfVehicleBridgeCoupling < handle
    %INVERSEOPERATIONVEHICLEBRIDGECOUPLING Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        sensorPureSignal
        forwardOpr
        measuredIdx
        measurementSnr
        noiseSeed
        noisySensorSignal % with time stamp
        sensorNoiseCov
        simDuration
        simTimeSignal

        stateCnt
        knownInputCnt
        unknownInputCnt
        measurementCnt
        stateSpaceInitCond
        wheelsetTimeDelay

        Qx
        Qr
        Qa
        Ry
        P0
    end
    
    methods
        function obj = InverseOperationByAkfVehicleBridgeCoupling(sensorPureSignal,signalTimeStamp,forwardOpr,measuredIdx,measurementSnr,noiseSeed)
            inputDimensionOk=obj.checkInputDimension(sensorPureSignal,signalTimeStamp,measuredIdx,measurementSnr,noiseSeed);
            if ~inputDimensionOk
                error("Incompatible inputs.");
            end
            obj.sensorPureSignal=sensorPureSignal;
            obj.forwardOpr=forwardOpr;
            obj.measuredIdx=measuredIdx;
            obj.measurementSnr=measurementSnr;
            obj.noiseSeed=noiseSeed;
            [obj.noisySensorSignal,obj.sensorNoiseCov]=obj.addNoise(sensorPureSignal,measurementSnr,noiseSeed);
            obj.noisySensorSignal=[signalTimeStamp,obj.noisySensorSignal];
            obj.simDuration=signalTimeStamp(end);
            obj.simTimeSignal=[0,0;obj.simDuration,obj.simDuration];
            obj.stateCnt=forwardOpr.stateCnt+1;
            obj.knownInputCnt=forwardOpr.stateCnt/2;
            obj.unknownInputCnt=1;
            obj.calDefaultAkfNoisePara();
            obj.measurementCnt=length(measuredIdx);
            obj.stateSpaceInitCond=[obj.forwardOpr.stateSpaceInitCond;
                                zeros(obj.unknownInputCnt,1)];
            obj.wheelsetTimeDelay=abs(diff(obj.forwardOpr.veh14dof.wheelPositions))/obj.forwardOpr.velocity;
        end

        function obj = calDefaultAkfNoisePara(obj)
            obj.Ry = obj.sensorNoiseCov;
            obj.Qx = 1e-4*ones(obj.forwardOpr.stateCnt,1);
            obj.Qr = 1e-1*ones(obj.unknownInputCnt,1);
            obj.Qa = diag([obj.Qx; obj.Qr]);
            obj.P0 = 1;
        end
    end

    methods(Static)
        function dimensionOk = checkInputDimension(sensorPureSignal,signalTimeStamp,measuredIdx,measurementSnr,noiseSeed)
            dimensionOk = true;
            if ~isvector(measuredIdx) || ~isvector(signalTimeStamp) || ~isvector(measurementSnr)
                dimensionOk = false;
                return;
            end
            if ~isscalar(noiseSeed) || rem(noiseSeed, 1)~=0
                dimensionOk = false;
                return;
            end
            signalChannelCnt = size(sensorPureSignal,2);
            signalPtCnt = size(sensorPureSignal,1);
            timePtCnt = length(signalTimeStamp);
            measuredIdxCnt = length(measuredIdx);
            measuredSnrCnt = length(measurementSnr);
            if measuredIdxCnt~=signalChannelCnt
                dimensionOk = false;
                return;
            end
            if signalPtCnt~=timePtCnt
                dimensionOk = false;
                return;
            end
            if measuredSnrCnt~=signalChannelCnt && measuredSnrCnt~=1
                dimensionOk = false;
                return;
            end
        end

        function [noisySignal,noiseCovMat] = addNoise(pureSignal,signalSnr,noiseSeed)
            channelCnt = size(pureSignal, 2);
            noisySignal = zeros(size(pureSignal));
            noiseCovMat = zeros(channelCnt);
            if  signalSnr > 100    % 不考虑噪声
                noisySignal = pureSignal;
                for iChannel = 1:channelCnt
                    noiseCovMat(iChannel, iChannel) = 1e-10;
                end
            else
                if isscalar(signalSnr)
                    signalSnr = signalSnr * ones(channelCnt, 1);
                end
                pureSignalMean = mean(pureSignal, 1);
                for iChannel = 1:channelCnt
                    iNoisySignalWioutMean = awgn(pureSignal(:, iChannel)-pureSignalMean(iChannel), signalSnr(iChannel), 'measured', noiseSeed+iChannel, 'dB');
                    noisySignal(:, iChannel) = iNoisySignalWioutMean + pureSignalMean(iChannel);
                    noiseCovMat(iChannel, iChannel) = cov(noisySignal(:, iChannel) - pureSignal(:, iChannel));
                end
            end
        end
        
    end
end

